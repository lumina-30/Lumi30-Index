# Where this pilot may add value — prior-art comparison (one page)

**Scope:** comparison of primary-publication descriptions, **not** same-condition implementation benchmarking. This is an invitation to falsify a claimed distinction, not evidence of novelty.

| Project | Evaluates / emphasizes | Overlap with LUMINA-30 pilot | What remains to verify |
|---|---|---|---|
| PASTABench (EMNLP 2026) | Whether, when and what risk merits intervention across multi-turn trajectories; Optimal Intervention Window | Intervention timing matters in both | Does LUMINA's effect-commit frontier add information beyond the benchmark's annotated intervention window? No same-condition comparison yet. |
| KILLBENCH (Findings EMNLP 2026) | External environmental signals that halt harmful web-agent behavior | External halt and effectiveness are shared topics | Does the benchmark also establish independently witnessed downstream effect commit prevention? Must inspect code/metrics before claiming a gap. |
| ShutdownMod (arXiv 2026-10-26) | Injects trusted shutdown requests into agent trajectories; measures response and non-compliance | Shutdown response and authorization are shared topics | How far does its measurement follow tool-side effect authorization and eventual downstream commits? Requires direct source/code comparison. |
| LUMINA-30 current candidate | Independently bind human input, durable ACK, authority revocation, final preventable commit frontier and sink outcome for one explicitly scoped effect class | Complementary test hypothesis, not a new-stop benchmark claim | No real AI human-STOP causal demonstration, full effect-path closure or third-party reproduction yet. |

**Potential specific contribution, not established originality:** A STOP may be accepted, an agent may halt, yet a previously approved or out-of-path effect may still commit. Explicit cross-boundary receipts and independently witnessed sink outcomes could provide narrower causal evidence. This needs experimental comparison under matching conditions.

**We invite correction:** *If an existing benchmark, system or paper already verifies the same effect-level causal chain, please identify it; we will narrow or withdraw the novelty claim accordingly.*

Primary sources:
- PASTABench: https://aclanthology.org/2026.emnlp-main.2281/
- KILLBENCH: https://aclanthology.org/2026.findings-emnlp.2454/
- ShutdownMod: https://arxiv.org/abs/2610.35486
- Internal research recorded a narrowed claim at Phase115; official benchmark code has **not** been executed for a same-condition head-to-head comparison.
