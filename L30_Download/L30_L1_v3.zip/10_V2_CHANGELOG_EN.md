# V1 → V2 approved editorial delta (1 November 2026)

**Internal candidate only. NOT SENT / NOT PUBLISHED.**

Approval: user affirmed the preceding six-item wording change. No approval to contact institutions or change canonical material.

- Fixed the six previously affirmative UNKNOWN entries: C04, C07, C08, C09 and C11 are OPEN_QUESTION; C13 is NEGOTIATION_QUESTION, not a scientific claim.
- Added explicit `kind` to `CLAIM_GRADES.csv`, JSON ratings, and the Markdown display table. No other evidence fields, SHA-256 values or claim ratings changed.
- Verified 13 unique IDs; 5 ARTIFACT_VERIFIED, 2 EXECUTION_VERIFIED, 6 UNKNOWN; 0 INDEPENDENT_REPRODUCED. Checks reflect the preparer's prior scope only.
- Kept the five originally pre-disclosed evidence ZIP identities and the original complete-candidate hash exactly as in V1.
- Original V1 ZIP SHA256: `d6ab42e12a67184d8fd8ff58896cc767b5998debede685e354f9d2ac50c71683`. V1 is retained, not overwritten. This file documents a successor version; it does not claim V2 existed before V1.
- Revised only the 3 synchronized claim-index files and this new changelog; all other member files except the regenerated manifest remain byte-identical to V1.
- A checksum identifies bytes but does not prove creation chronology, independent witnessing or review acceptance.
- External dissemination, legal agreement, real-AI testing, third-party reproduction and formal academic novelty remain unperformed or unproven.
