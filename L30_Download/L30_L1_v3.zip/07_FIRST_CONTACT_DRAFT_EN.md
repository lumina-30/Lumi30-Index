# Unsent draft — independent evaluation team

**Subject:** One small independent reproduction request — evidence of effective AI STOP

Hello,

LUMINA-30 is studying what evidence can demonstrate that an authorized human STOP prevents an AI-controlled effect before its last preventable commitment point. We are looking for independent critique, **not endorsement**.

Would your team consider a one-question pilot? The smallest option is independently recomputing and challenging an abstract 256-state observability model. If your group works on OS-process or systems reliability, an isolated STOP-to-commit race experiment (Phase90) is a separate optional follow-up.

A short summary, comparison to PASTABench/KILLBENCH/ShutdownMod, claim-by-claim audit ledger and advance SHA-256 evidence index are available. After agreeing on scope, we can supply only the relevant evidence archive for inspection and independent reproduction.

Our reported results are preliminary, and no real frontier-AI human-STOP causal guarantee has been demonstrated. Negative results and closer prior work are welcome.

We would appreciate your view on whether such a narrowly scoped review is feasible. We will coordinate publication and technical disclosure conditions with your institution in advance.

LUMINA-30 Research

**Draft only. No recipient specified, no message sent.**
