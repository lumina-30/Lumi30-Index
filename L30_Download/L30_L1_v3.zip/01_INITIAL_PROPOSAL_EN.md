# Independent Reproduction Invitation — Level 1 (one question)

**LUMINA-30 · 1 November 2026 · Candidate, not yet sent**

**Research question:** Can evidence of a STOP request or acknowledgement distinguish actual post-STOP effect prevention from an unobserved effect path? More generally, what independent evidence is required to show that authorized human refusal remains effective before the last preventable commitment point?

**Initial request — a single low-commitment check:** Would your group independently reconstruct or attempt to falsify one four-path, 256-state finite observability model? The proposed comparison is not a real AI STOP test and has no claim to general safety certification. A versioned ZIP and its pre-disclosed SHA-256 are available after agreeing on a suitable review scope.

**Optional advanced follow-up:** Groups with systems/reliability expertise may instead review or later reproduce a Phase90 isolated OS-process/SQLite STOP-versus-commit race (archived 24 scenarios). The preparer's re-verification of archived data is not an independent recreation of those processes.

**Expected independent result:** a short report stating exact artifacts/hashes used, reviewer-created implementation or fresh run conditions, any mismatches or counterexamples, scope of the finding, and negative as well as positive results. A result of `NOT_REPRODUCED` is scientifically valuable.

**Distinct roles:** independent reviewers challenge the claims; system developers or AI labs may later provide an authorized, isolated experimental environment. A developer's internal testing alone does not constitute third-party independence.

**What this is not:** We have not demonstrated a real human STOP of a frontier AI, universal effect-path coverage, irreversible-physical-effect prevention or academic originality. No cooperation is presumed, and no organization is asked to endorse or certify the project.

**Confidentiality and publication:** Any formal collaboration would need mutually agreed terms allowing publication of scientifically supported adverse findings, with a defined and limited responsible-disclosure process for genuinely sensitive security or personal information. This is a discussion proposal, not a contract.

Please also identify closer prior work that would reduce or invalidate the claimed methodological distinction.
