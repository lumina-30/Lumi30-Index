# Staged disclosure and fixed-evidence identification — proposed

## Stage 0: Initial invitation and index (this bundle)
Disclose a short question, the benchmark comparison, per-claim audit levels and **byte hashes** for relevant original archives. No experiment scripts, raw logs, vulnerabilities or personal information are bundled.

At first transmission, the sender and receiving reviewer should separately retain the exact Stage-0 ZIP SHA256, the claim ledger, and the evidence SHA256 values. A checksum alone does not prove chronology, authenticity, ownership or immutability; an independent timestamp or signed receipt can strengthen provenance if agreed.

## Stage 1: One narrowly agreed reproduction
Default: OBS-256 archive `L30_Stop_Observability_Proof_20261031.zip` SHA256 `3ca512585ad849ae1dddddd8379a7bea5e0ad5627bc9137a1da6816c31fe2542`. Recipient first inspects any source before execution in an institution-approved offline sandbox. Request an independently coded comparison or fresh bounded re-run; do not count re-running the preparer's checker as fully independent reproduction.

## Stage 2: Optional OS-process reproduction
If relevant and authorized: P90-OS archive `L30_Phase90_STOP_Intent_Race_20261031.zip` SHA256 `16c05965596bf655eef39e17d72a2b998b3cd44d61cf7285c464e9a5f9eff9ba`. Use fresh disposable directories, preserve original archive unmodified, record OS/Python/SQLite versions, all process results and counterexamples. A validator reading historical SQLite alone is **not** an independent fresh process trial.

## Later stage: Live AI human-STOP test
No approved actual environment exists in this package. The agent, effect executor, human supervisor and independent observer would require explicit institutional authorization, isolation, pre-registration and risk review. Do not infer generic guarantees from local fixtures.

## Publication and escalation
Both positive and negative results should be reportable. Proposed responsible-disclosure terms must protect genuinely sensitive third-party information or exploit-enabling details without allowing indefinite scientific-result suppression. All scope, licensing and publication permissions remain unagreed.
