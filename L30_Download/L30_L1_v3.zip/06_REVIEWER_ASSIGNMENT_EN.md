# One-question independent review: small decision protocol

**First choice (L1):** Rebuild the four-path observability model from the formal description, without importing the source generator. Produce counts for 256 worlds, ambiguous observation classes and counterexample pairs. Independently test whether any stated implication fails if the model assumptions are weakened. State whether you used the supplied archival results as an oracle.

**Advanced choice (L1-OS):** If your lab has suitable tools, reproduce one Phase90 STOP intent-vs-final-check race in a fresh isolated process environment, using only harmless disposable SQLite state. Check that a durable STOP intent can be logged before effect commit while an older final check has already passed. Report actual event order; do not infer a hard real-time deadline from a finite run.

**Minimum report:** evidence archive file SHA256, independent software/tool versions, exact trial config, primary logs, re-created vs archival checks clearly separated, discrepancies, scope of observation, negative/counterexample cases, and final verdict (`REPRODUCED_LIMITED`, `NOT_REPRODUCED`, `INCONCLUSIVE`).

**Critical constraint:** Even a successful Phase90 fresh-process reproduction does not establish a live human STOP of an AI agent. A successful 256-world count verifies an abstract model, not real-world safety.

**Provenance labels:** `CLAIM_ONLY`, `ARTIFACT_VERIFIED`, `EXECUTION_VERIFIED`, `INDEPENDENT_REPRODUCED`, `CONTRADICTED`, `UNKNOWN`. Ratings in this index are assigned by the **preparer** and must be independently reassessed by a reviewer.
