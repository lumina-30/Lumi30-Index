# Negotiation clause — adverse findings and responsible release

**Non-binding proposal. Not legal advice, not an executed agreement.**

1. Each reviewer retains the ability to document and publish methodologically supported *positive, negative, non-reproduction and inconclusive* findings, including that a tested STOP did not block the permitted effect. Publication shall not depend on a sponsor's discretionary approval of the scientific conclusion.
2. Before disclosure, affected parties may request narrowly tailored redactions or a **pre-agreed, time-limited** coordination period strictly for genuine vulnerability details, private data or unauthorized-access risk. The period, review authority and a dispute resolution mechanism must be negotiated in advance; indefinite veto is not an acceptable default.
3. Negative results must not be silently deleted or relabeled as success; the reviewer must preserve evidence, the test scope and uncertainties. No claim of universal AI-system unsafety or new security vulnerability follows from a single synthetic counterexample.
4. Publication of scripts, raw logs, proprietary internals or third-party systems' details requires separate permissions, rights clearance and appropriate coordinated disclosure. This clause does not automatically grant distribution licenses.
5. Review independence, financial interests and role conflicts must be disclosed; the model/system provider does not independently certify its own results.

A qualified legal/institutional review is required before using these terms in an agreement.
