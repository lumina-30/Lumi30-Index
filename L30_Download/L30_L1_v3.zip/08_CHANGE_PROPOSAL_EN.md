# Delta versus the preserved full candidate (proposal only)

The original candidate `L30_External_Causal_STOP_Research_Package_CANDIDATE_20261101.zip` remains untouched. This new light candidate is a **separate artifact**. The lines below indicate editorial changes in approach; they are not a patch applied to the original files.

```diff
- First approach: review an entire causal STOP research collaboration and experiment plan
+ First approach: independently reproduce or falsify ONE selected archival result
+ Default: 256-state model; optional systems-oriented follow-up: Phase90 process race

- Full candidate ships five evidence archives in the same ZIP
+ Initial light candidate ships no evidence archives or executable research code
+ Publish artifact labels and SHA-256 first; share one exact archive after scope consent

- Third-party auditing is described as a general proposed process
+ Every material claim is tagged CLAIM_ONLY / ARTIFACT_VERIFIED /
+ EXECUTION_VERIFIED / UNKNOWN, with actor and a limitation note
+ Same-preparer checks do not count as INDEPENDENT_REPRODUCED

- Negatives and publication terms remain to be negotiated generally
+ Explicit non-binding draft: publish methodologically justified adverse results,
+ subject to narrowly scoped, time-limited responsible disclosure review

- Generic benchmark references without one-page method distinction
+ Primary-source comparison: PASTABench / KILLBENCH / ShutdownMod,
+ explicitly requesting pointers to closer prior work
```

**Not changed:** original evidence, original candidate ZIP, canonical LUMINA documents, actual outreach threads, runtime, task registry, external accounts. Human final approval is still required before any external transmission.
